"""
AL Drones Population Analysis Tool
Main package for drone safety analysis.
"""

__version__ = '1.0.0'
__author__ = 'AL Drones'
__email__ = 'contato@aldrones.com.br'
